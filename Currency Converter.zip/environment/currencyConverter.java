//This is my first independent project please feel free to give 
//any critiques as I am trying to get better 
import java.util.*;
import java.text.DecimalFormat;

public class currencyConverter {
public static void main(String[] args){
    Scanner scnr =  new Scanner(System.in); 
    //declare all variables
    double dollar;
    double rupee;
    double pound;
    double code;// scans for userinput
    double euro;
    double yen;
    //This declaration formats all of the numbers allowing you to parse through strings/functions
    DecimalFormat f = new DecimalFormat("##.###");
    
    System.out.println("Enter the following number to currency \n1:Rupees\n2:Dollar\n3:Pound\n4:Euro\n5:Yen");

         code=scnr.nextInt();
        //for Rupee conversion
        if (code == 1){
            System.out.println("Please Enter the amount of Rupees: ");// Ask user how much Rupees
            rupee = scnr.nextFloat();//userinput Rupee
            
            dollar = rupee/66;//Dollar format
            System.out.println("Dollar : "+f.format(dollar));
            
            pound = rupee/98;//pound format
            System.out.println("Pound: "+f.format(pound));
            
            euro = rupee/72;// Euro format
            System.out.println("Euro: " + f.format(euro));
            
            yen = rupee/0.55; // yen format
            System.out.println("Yen: " + f.format(yen));
            }//end of Rupee conversion 1
            
        else if(code == 2){
           
            System.out.println("Please Enter the amount of Dollars: ");
            dollar = scnr.nextFloat();// userinput for amount of dollars
            
            //Dollar to Rupee conversion
            rupee = dollar * 66;
            System.out.println("Rupees: "+ f.format(rupee));
            
            //Dollar to pound conversion
            pound = dollar*0.67;
            System.out.println("Pounds: "+f.format(pound));
            
            //Dollar to Euro
            euro = dollar*0.92;
            System.out.println("Euros: " + f.format(euro));
            
            //Dollar to Yen
            yen = dollar*120.90;
            System.out.println("Yen: "+ f.format(yen));
            
        }// end of Dollar Conversion 2
        
        else if (code == 3){
            //pound conversion
            System.out.println("Please enter the amount of Pounds: ");
            pound = scnr.nextFloat();
            
            //Pound to Rupee conversion
            rupee = pound * 98;
            System.out.println("Rupees: "+ f.format(rupee));
            
            //Pound to Dollar conversion
            dollar = pound * 1.49;
            System.out.println("Dollars: "+ f.format(dollar));
           
            //Pound to Euro conversion
            euro = pound *1.36;
            System.out.println("Euro: " + f.format(euro));
            
            //Pound to Yen conversion
            yen = pound *179.89;
            System.out.println("Yen: "+ f.format(yen));
            
            
        }// End of Pound conversion
        
        //EURO CONVERSION
        else if (code == 4){
            System.out.println("Please enter the amount of Euros: ");
            euro = scnr.nextFloat();
            
            //Euro to Rupee conversion
            rupee = euro*72;
            System.out.println("Rupees: "+ f.format(rupee));
            
            //Euro to Dollar conversion
            dollar = euro*1.09;
            System.out.println("Dollars: "+f.format(dollar));
            
            //Euro to pound
            pound = euro*0.73;
            System.out.println("Pounds: "+ f.format(pound));
            
            //Euro to Yen
            yen = euro * 131.84;
            System.out.println("Yens: "+ f.format(yen));
        }//end of euro conversion
        
        //Yen conversion
        else if(code == 5){
            System.out.println("Please enter the amount of Yen: ");
            yen = scnr.nextFloat();
            
            //Yen to Rupee conversion
            rupee = yen*0.55;
            System.out.println("Rupees: " + f.format(rupee));
            
            //yen to dollar conversion
            dollar = yen*0.01;
            System.out.println("Dollar: " + f.format(dollar));
            
            //Yen to pound conversion
            pound = yen*0.01;
            System.out.println("Pounds: " + f.format(pound));
            
            //Yen to Euro conversion
            euro = yen*0.01;
            System.out.println("Euro: " + f.format(euro));
            
        }//End of Yen conversion
        
        else{
            System.out.println("Invalid code");
        }// End of else statement
        
        
}// end of main
}// end of class