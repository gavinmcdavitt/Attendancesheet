
public class snakeGame{
    
    Public static void main(String[] args){
        
    }//end of main
}//end of class "Snakegame"
public class GameFrame extends JFrame{
    
}