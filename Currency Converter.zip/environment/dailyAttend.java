import java.util.Scanner; 

public class dailyAttend {
public static void main(String[] args){
    
    Scanner scnr = new Scanner(System.in);
    System.out.print("How many students are in your class?");
    int amountOfStudents= scnr.nextInt();
    String [] attendance= new String[amountOfStudents];
    String [] here = new String[amountOfStudents];
    String student;
    String input;
    int i;//while loop
    int j;
    int index;
    for(i=0;i<amountOfStudents;i++){
        System.out.print("What are your students names: ");
        attendance[i] = scnr.next();
        System.out.print("Is "+ attendance[i] + " in class today?");
        here[i]=scnr.next();
    }
    
    for(index =0; index < amountOfStudents; index++){
        if(here[index].equalsIgnoreCase("yes")){
            System.out.println("These Students are in class: " + attendance[index]);
        }//end of if
        if(here[index].equalsIgnoreCase("no")){
            System.out.println("These Students are absent: " + attendance[index]);
        }
        
    }
    
    /*
    do{
        attendance[i] = scnr.next();
        System.out.print("Is " + attendance[i] + " here? Please enter yes or no: ");
        input=scnr.next();
            if(input.equalsIgnoreCase("yes")){
                here[i]=true;
            }
            else if (input.equalsIgnoreCase("no")){
                here[i]=false;
            }
        i++;
    }//end of do while loop
    while(i<amountOfStudents);
   */
    
    
    
}//end of main
}//end of class