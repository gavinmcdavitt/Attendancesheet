import java.util.*;
import java.text.DecimalFormat;

public class notes {
public static void main(String[] args){
    Scanner scnr =  new Scanner(System.in); 
    int []num = new int [5];
    
    for (int i =0; i<=4; i++){
        System.out.print("Please enter a number: ");
        num[i]= scnr.nextInt();
        
    }//end of for loops
    for (int element:num){
    System.out.print(element + ", ");
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    /*whoIsHere(attendance, amountOfStudents);
    
}//end of main class
public static boolean whoIsHere(String[] present, int amount){//fix boolean later
    //This method is used to see who is in class
    Scanner scnr = new Scanner(System.in);
   int i;
   int j;
   boolean[] here = new boolean[amount];
   String yes;
   
   for(j=0; j<present.length;j++){
    for(i=0; i<present.length;i++){
        System.out.print("Is "+ present[i] + " here? Please enter (yes) or (no): ");
        yes= scnr.next();
        if(yes.equalsIgnoreCase("yes")){
            here[i] = true;
        }//end of if
        else if(yes.equalsIgnoreCase("no")){
            here[i] = false;
        }//end of else if
        
        
            
        
        
        //return true;//fix me later
    }//end of for loop
    if(here[j] = true){
        System.out.print("This student is here: " + present[j]);
    }//end of inner if
    else if (here[j]= false){
        System.out.print("This student is absent: " + present[j]);
            }//end of else if
    
   }//end of outer for statement
    return false;//fix me later
    
   
}//end of method "whoIsHere"
*/
    
}//end of main
}//end of class